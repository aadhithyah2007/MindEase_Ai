MindEase AI — Peaceful Nature Edition

Open index.html in Chrome, Edge, or a mobile browser. Keep peaceful_lake.jpg in the same folder.

Features: mood tracking, journal, breathing exercise, sleep log, meditation prompts, simple wellness companion, ambient tones, interactive ripples and drifting petals.

All entries are saved in local browser storage on this device. Clearing browser data deletes them. This is a web app, not an Android APK. The companion is prewritten, not a live AI model.

For privacy, avoid entering highly sensitive medical details in this prototype.
